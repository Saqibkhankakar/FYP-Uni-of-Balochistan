# Verification record

Executed on **26 October 2026**, using PHP **8.3.36** and a real **MySQL 8.0.45 / InnoDB** server on an isolated loopback port. The installed MySQL databases were not modified. The application's timezone and database session were set to Pakistan time.

## Automated tests executed

**38 database integration assertions passed** (`tests/run.php`):

- Database connectivity and schema installation in a randomly named disposable test database.
- Recurring weekday upsert without duplicates; capacity calculation, including 36 five-minute positions in three hours.
- Opening boundary, exact cutoff, future advance bookings, past dates, non-working weekdays and 30-day horizon.
- Pakistani phone rejection and normalization.
- Token allocation, estimates, unpredictable private tokens and duplicate-submission idempotency.
- Full-capacity rejection for online bookings and walk-ins.
- Safe absence handling; booked-date snapshots preserved after schedule edits.
- Cancellation, position reuse, monotonic replacement tokens and unchanged existing estimates.
- Database uniqueness rejection of a deliberately colliding position.
- Arrival, completion, current consultation exclusivity, future consultation rejection and no-show recovery.
- Inactive doctor rejection and independent queues per doctor/date.
- **Eight independent PHP processes booking simultaneously:** eight distinct sequential tokens and positions.
- **Eight processes competing for three positions:** exactly three accepted, five rejected as full.
- Database-backed rate limiting.

**37 HTTP assertions passed** (`tests/http_smoke.py`):

- Actual first-admin CLI creation using a random password through stdin; no password stored in source.
- Admin and receptionist login, session cookie flags, authentication redirects and admin route authorization.
- CSRF rejection, doctor creation, valid photo re-encoding, SVG upload rejection, recurring schedule creation and receptionist account creation.
- Public booking without login, private confirmation link, estimated time, HTML escaping, no-referrer/no-store headers and duplicate submission protection.
- Reopening a private link in a separate session; sequential IDs and invalid private tokens cannot expose an appointment.
- Walk-in booking, full-capacity display, patient search, arrival, cancellation and replacement with a new stable token.
- Complete staff-only patient print list, correct token order including cancellations, and private file access protection through the local development router.
- Receptionist deactivation invalidates an already signed-in session.

Temporary HTTP test staff, doctors, uploads and appointments were cleaned up by the test harness. Random test databases were dropped after the integration run. The fictional installation demo data was preserved.

## Browser checks executed

- Rendered the public homepage, booking page, confirmation, staff login, admin overview, schedule editor, reception dashboard, queue and full patient-list page in the in-app Chromium browser.
- Completed a real no-login booking with fictional details and confirmed the resulting slip, token and estimate.
- Signed in with a temporary admin account, opened schedules, selected a future reception date and opened its populated queue and printable list.
- Checked responsive layouts at **390 px**, **768 px**, and **1440 px** viewport overrides. Homepage, slip, admin overview and queue checks found no document-level horizontal overflow; wide staff tables scroll within their containers.
- Checked the mobile navigation toggle. Checked homepage images loaded successfully.
- Captured representative screenshots under `tests/screenshots/`.

## Remaining manual verification

- **XAMPP/Apache and its bundled MariaDB were not available on this computer.** PHP and actual MySQL were tested; a fresh XAMPP installation and Apache `.htaccess` behavior still need a target-laptop check. The local development router's equivalent private-path restrictions passed HTTP tests.
- **Native print/PDF dialog and physical paper output are not verified.** The print action was attempted in the embedded browser but its native dialog was not accessible to the automation. Both pages, required columns, token ordering and print CSS exist; browser print pagination must be checked in normal Edge/Chrome on the destination laptop. Test A4 at 100% scale, with browser headers/footers off. For a long queue, verify repeated headers and no cut-off rows.
- The Windows masked PowerShell first-admin prompt was source-reviewed, but was not driven interactively. The underlying PHP CLI account creation and subsequent login were executed successfully through stdin.
- Offline operation on a physically disconnected laptop and transfer to a second laptop have not been executed. All runtime frontend dependencies are local; the handover archive excludes development configuration and credentials.

## Run the checks yourself

```powershell
# PHP + MySQL/MariaDB only; creates its own disposable database.
& C:\xampp\php\php.exe tests\run.php

# Optional HTTP suite: requires Python only for testing, and Apache/MySQL running.
python tests\http_smoke.py --php C:\xampp\php\php.exe --url http://localhost/doctor-hospital

# Syntax check all project PHP files.
Get-ChildItem -Recurse -Filter *.php | ForEach-Object { & C:\xampp\php\php.exe -l $_.FullName }
```

The first-admin assertion runs only when the hospital database contains no admin; otherwise the HTTP harness creates its own temporary admin and reports 36 HTTP assertions. Run HTTP tests in a demonstration database: they briefly create real staff accounts and use the public rate-limit bucket for loopback traffic.

## Demonstration checklist

1. Create the first admin, then a receptionist account.
2. Add a doctor, upload a photo and save two different weekly schedules.
3. Book a future appointment as a patient without signing in.
4. Save the private link, open it in a new session and print/save the slip.
5. As receptionist, select that date, search for the patient and mark them Arrived.
6. On today's test clinic, call a patient into consultation, then complete the visit.
7. Cancel a booking and refill it. Confirm other tokens/times did not move.
8. Use a short consultation period to demonstrate full capacity.
9. Print the full doctor/date list and confirm its A4 layout.
10. Mark an empty future date unavailable and verify patients cannot book it.
