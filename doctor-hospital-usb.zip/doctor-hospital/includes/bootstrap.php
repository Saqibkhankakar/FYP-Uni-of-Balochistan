<?php
declare(strict_types=1);
$config = require dirname(__DIR__) . '/config.php';
date_default_timezone_set($config['timezone']);
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/booking.php';
if (PHP_SAPI !== 'cli') {
    ini_set('session.use_strict_mode', '1');
    session_name('doctor_hospital_session');
    session_set_cookie_params(['httponly' => true, 'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off', 'samesite' => 'Lax', 'path' => ($config['base_url'] ?: '') . '/']);
    session_start();
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: no-referrer');
    header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'");
    header('Cache-Control: no-store');
    set_exception_handler(function (Throwable $e) {
        error_log((string)$e);
        http_response_code(500);
        // The error page must not call staff() or query the database again.
        echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Request unavailable · Doctor Hospital</title><link rel="stylesheet" href="' . e(url('assets/vendor/bootstrap.min.css')) . '"><link rel="stylesheet" href="' . e(url('assets/css/style.css')) . '"></head><body><main class="container section"><div class="panel"><h1>We couldn’t complete that request.</h1><p>Please try again. For a new installation, follow the database setup steps in README.md and check your local database settings.</p><a class="btn btn-primary" href="' . e(url('/')) . '">Return home</a></div></main></body></html>';
    });
}
