'use strict';
document.querySelectorAll('[data-print]').forEach(button => button.addEventListener('click', () => window.print()));
document.querySelectorAll('[data-confirm]').forEach(form => form.addEventListener('submit', event => {
  if (!window.confirm(form.dataset.confirm)) event.preventDefault();
}));
document.querySelectorAll('form').forEach(form => form.addEventListener('submit', () => {
  // Do not disable controls: named submit buttons carry action values on some forms.
  form.classList.add('submitted');
}));
document.getElementById('copy-link')?.addEventListener('click', async () => {
  const status = document.getElementById('copy-status');
  try {
    await navigator.clipboard.writeText(window.location.href);
    status.textContent = 'Private link copied. Store it safely and share only with people you trust.';
  } catch {
    status.textContent = 'Copy the full address from your browser’s address bar, or bookmark this page.';
  }
});
