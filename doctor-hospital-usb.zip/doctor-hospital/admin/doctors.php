<?php
require dirname(__DIR__).'/includes/bootstrap.php'; require_role('admin'); $title='Manage doctors'; $error=null;
if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf();
    try {
        $id=(int)($_POST['id'] ?? 0); $name=required_text((string)($_POST['name'] ?? ''),'Doctor name');
        $specialization=required_text((string)($_POST['specialization'] ?? ''),'Specialization');
        $qualifications=required_text((string)($_POST['qualifications'] ?? ''),'Qualifications',200);
        $phone=phone_number((string)($_POST['phone'] ?? '')); $active=isset($_POST['active']) ? 1 : 0;
        $photo=upload_photo($_FILES['photo'] ?? null);
        db()->beginTransaction();
        try {
            if ($id) {
                if (!one('SELECT id FROM doctors WHERE id=? FOR UPDATE',[$id])) throw new DomainException('Doctor not found.');
                query('UPDATE doctors SET name=?,specialization=?,qualifications=?,phone=?,active=?,photo=COALESCE(?,photo) WHERE id=?',[$name,$specialization,$qualifications,$phone,$active,$photo,$id]);
            } else { query('INSERT INTO doctors (name,specialization,qualifications,phone,active,photo) VALUES (?,?,?,?,?,?)',[$name,$specialization,$qualifications,$phone,$active,$photo]); }
            db()->commit();
        } catch (Throwable $e) { db()->rollBack(); throw $e; }
        flash('Doctor saved. Existing appointments remain in the staff queues.'); redirect('admin/doctors.php');
    } catch (DomainException $e) { $error=$e->getMessage(); }
}
$edit=isset($_GET['edit']) ? one('SELECT * FROM doctors WHERE id=?',[(int)$_GET['edit']]) : null;
if ($error) $edit=array_replace($_POST,['active'=>isset($_POST['active']) ? 1 : 0]);
$doctors=query('SELECT * FROM doctors ORDER BY active DESC,name')->fetchAll(); require dirname(__DIR__).'/includes/header.php';
?>
<main id="main" class="container section"><div class="section-heading"><div><div class="eyebrow">YOUR CARE TEAM</div><h1>Doctor management</h1><p class="muted">Keep your directory and doctor details up to date.</p></div></div><?php if($error): ?><div class="alert alert-danger" role="alert"><?= e($error) ?></div><?php endif; ?><div class="row g-4"><div class="col-xl-4"><form class="panel" method="post" enctype="multipart/form-data"><?= csrf_field() ?><input type="hidden" name="id" value="<?= e($edit['id'] ?? 0) ?>"><h2><?= !empty($edit['id'])?'Edit doctor':'Add a doctor' ?></h2><label for="name" class="form-label">Doctor name</label><input id="name" name="name" class="form-control mb-3" required maxlength="100" value="<?= e($edit['name'] ?? '') ?>" placeholder="Dr. Ahmed Khan"><label for="specialization" class="form-label">Specialization</label><input id="specialization" name="specialization" class="form-control mb-3" required maxlength="100" value="<?= e($edit['specialization'] ?? '') ?>"><label for="qualifications" class="form-label">Qualifications</label><input id="qualifications" name="qualifications" class="form-control mb-3" required maxlength="200" value="<?= e($edit['qualifications'] ?? '') ?>"><label for="phone" class="form-label">Mobile number</label><input id="phone" type="tel" name="phone" class="form-control mb-3" required maxlength="20" value="<?= e($edit['phone'] ?? '') ?>"><label for="photo" class="form-label">Doctor photo</label><input id="photo" name="photo" type="file" accept="image/jpeg,image/png,image/webp" class="form-control"><p class="form-text">JPG, PNG or WebP · up to 2 MB. Leave blank to keep the current photo.</p><div class="form-check my-4"><input class="form-check-input" type="checkbox" id="active" name="active" <?= ($edit['active'] ?? 1)?'checked':'' ?>><label for="active" class="form-check-label">Active and visible to patients</label></div><button class="btn btn-primary">Save doctor</button><?php if($edit): ?><a class="btn btn-light" href="<?= e(url('admin/doctors.php')) ?>">New doctor</a><?php endif; ?></form></div><div class="col-xl-8"><div class="panel"><h2>All doctors <span class="muted h6">(<?= count($doctors) ?>)</span></h2><p class="small muted">Deactivating hides a doctor from new bookings. Existing patients must be contacted separately if a clinic is cancelled.</p><div class="table-responsive"><table class="table align-middle"><thead><tr><th>Doctor</th><th>Contact</th><th>Status</th><th>Manage</th></tr></thead><tbody><?php foreach($doctors as $d): ?><tr><td><div class="person-cell"><img src="<?= e(doctor_photo($d)) ?>" alt=""><div><strong><?= e($d['name']) ?></strong><small><?= e($d['specialization']) ?></small></div></div></td><td><?= e($d['phone']) ?></td><td><?= status_badge($d['active']?'Active':'Inactive') ?></td><td><a href="?edit=<?= e($d['id']) ?>">Edit</a> <span class="muted">·</span> <a href="<?= e(url('admin/schedules.php?doctor='.$d['id'])) ?>">Schedule</a></td></tr><?php endforeach; ?><?php if(!$doctors): ?><tr><td colspan="4" class="py-5 muted">Add your first doctor to get started.</td></tr><?php endif; ?></tbody></table></div></div></div></div></main><?php require dirname(__DIR__).'/includes/footer.php'; ?>
