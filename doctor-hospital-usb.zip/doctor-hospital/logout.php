<?php
require __DIR__ . '/includes/bootstrap.php';
if ($_SERVER['REQUEST_METHOD']!=='POST') { http_response_code(405); header('Allow: POST'); exit; }
verify_csrf(); $_SESSION=[]; session_destroy();
setcookie(session_name(), '', ['expires'=>time()-3600,'path'=>($config['base_url'] ?: '').'/','httponly'=>true,'samesite'=>'Lax']);
redirect('login.php');
